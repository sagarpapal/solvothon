export class Employee {
    
    id : number
    name: string
    department: string
    salary: number
    status: boolean
    
}
