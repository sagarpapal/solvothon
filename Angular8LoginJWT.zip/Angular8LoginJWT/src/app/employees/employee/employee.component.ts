import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { EmployeeService } from 'src/app/_services/employee.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {

  constructor(private service : EmployeeService,
              private toster : ToastrService) { }

  ngOnInit() {
    this.resetForm();
  }

  resetForm(form? : NgForm) {
    if(form != null)
    form.resetForm();
    this.service.formData = {
      id : null,
      name : '',
      department : '',
      salary : 0,
      status : true

    }
  }


  onSubmit(form : NgForm) {
    console.log('on sumbit status:'+form.value.status);

    if(form.value.id == null)
     this.insertEmployee(form);
     else
     this.updateEmployee(form);
  }  

  insertEmployee(form : NgForm) {
    this.service.postEmployee(form.value).subscribe(res => {
      this.toster.success("Inserted Successfully", "EMP Register");
      this.resetForm(form);
      this.service.refreshList();
    })
  }

  updateEmployee( form : NgForm) {
    this.service.putEmployee(form.value).subscribe(res => {
      this.toster.info("Updated Successfully", "EMP Register");
      this.resetForm(form);
      this.service.refreshList();
    })
  }

}
