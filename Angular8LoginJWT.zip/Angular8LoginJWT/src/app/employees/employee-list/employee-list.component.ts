import { Component, OnInit } from '@angular/core';
import { EmployeeService } from 'src/app/_services/employee.service';
import { TokenStorageService } from 'src/app/_services/token-storage.service';
import { Employee } from 'src/app/_services/employee.model';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css']
})
export class EmployeeListComponent implements OnInit {

  private roles : string[];
  isLoggedIn = false;
  showSuperAdminBoard = false;
  
  constructor(private service : EmployeeService, 
              private tokenService : TokenStorageService,
              private toster : ToastrService) { }

  ngOnInit() {
    this.service.refreshList();

    this.isLoggedIn = !!this.tokenService.getToken();
    if (this.isLoggedIn) {
      const user = this.tokenService.getUser();
      this.roles = user.roles;
      this.showSuperAdminBoard  = this.roles.includes('ROLE_SUPERADMIN');
    }
  }

  populateForm(emp : Employee) {
    console.log("status:"+emp.status);

    this.service.formData = Object.assign({},emp);
  }

  onDelete(id : number) {
    if(confirm("Are you sure to delete this record?")) {
      this.service.deleteEmployee(id).subscribe(res=>{
        this.service.refreshList();
       this.toster.warning("Deleted Successfully", "EMP Register");
      });
    }
  }

}
