package com.lti.controller;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api")
public class TestController {
	
	/**
	 *  
  id |      name       
----+-----------------
  1 | ROLE_USER
  2 | ROLE_ADMIN
  3 | ROLE_SUPERADMIN

  
  id | username   Roles
----+----------
  1 | sagar       USER
  2 | neeraj      ADMIN
  3 | rekha       SUPERADMIN
  4 | pooja       USER
  5 | user        USER
  
  password- 1234567
  
  /all       - to all
  /user      - user, admin, superadmin
  /admin     - admin, superadmin
  /employees - user, admin, superadmin
  /employee , /employee/{id}  - admin, superadmin
  /employee/{id} (update) - admin, superadmin
  /employee/{id} (delete) - superadmin 
  
  
   
   * 
   * **/
	
	
	@GetMapping("/all")
	public String allAccess() {
		return "Public Content.";
	}
	
	@GetMapping("/user")
	@PreAuthorize("hasRole('USER') or hasRole('ADMIN') or hasRole('SUPERADMIN')")
	public String userAccess() {
		return "User Content.";
	}

	@GetMapping("/admin")
	@PreAuthorize("hasRole('ADMIN') or hasRole('SUPERADMIN')")
	public String adminAccess() {
		return "Admin Board.";
	}
	
}	
