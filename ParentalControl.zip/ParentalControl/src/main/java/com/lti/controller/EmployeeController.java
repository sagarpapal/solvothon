package com.lti.controller;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.lti.dao.EmployeeDao;
import com.lti.model.Employee;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api")
public class EmployeeController {
	
	private static final Logger logger = LoggerFactory.getLogger(EmployeeController.class);
	
	@Autowired
	private EmployeeDao dao;
	
	  @GetMapping("/employees")
	  @PreAuthorize("hasRole('USER') or hasRole('MODERATOR') or hasRole('ADMIN') or hasRole('SUPERADMIN')")
	  public ResponseEntity<List<Employee>> getAllEmployees() {
		  logger.info("Class :"+getClass().getName()+ " Method: " +new Object(){}.getClass().getEnclosingMethod().getName());
		  try {
			  return new ResponseEntity<>(dao.findAll(), HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	  }
	  
	  @PostMapping("/employee")
	  @PreAuthorize("hasRole('ADMIN') or hasRole('SUPERADMIN')")
	  public ResponseEntity<Employee> addEmployee(@RequestBody Employee employee) {
		  logger.info("Class :"+getClass().getName()+ " Method: " +new Object(){}.getClass().getEnclosingMethod().getName());
		  try {
			  employee.setCreatedAt(new Date());
			  employee.setUpdatedAt(new Date());
			  Employee _employee = dao.save(employee);
			  return new ResponseEntity<>(_employee, HttpStatus.CREATED);
		} catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	  } 
	  
	  @GetMapping("/employee/{id}")
	  @PreAuthorize("hasRole('ADMIN') or hasRole('SUPERADMIN')")
	  public ResponseEntity<Employee> getEmployeeById(@PathVariable("id") Long id) {
		  logger.info("Class :"+getClass().getName()+ " Method: " +new Object(){}.getClass().getEnclosingMethod().getName());
		  try {
			Optional<Employee> employee = dao.findById(id);
			
			if(employee.isPresent()) {
				return new ResponseEntity<Employee>(employee.get(), HttpStatus.OK);
			}else {
				return new ResponseEntity<>(HttpStatus.NOT_FOUND);
			}
			  
		} catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	  }
	  
	  @PutMapping("/employee/{id}")
	  @PreAuthorize("hasRole('MODERATOR') or hasRole('ADMIN') or hasRole('SUPERADMIN')")
	  public ResponseEntity<Employee> updateEmployee(@PathVariable("id") Long id, @RequestBody Employee employee) {
		  logger.info("Class :"+getClass().getName()+ " Method: " +new Object(){}.getClass().getEnclosingMethod().getName());
		  try {
			Optional<Employee> employeeData = dao.findById(id);
			
			if(employeeData.isPresent()) {
				Employee entity = employeeData.get();
				
				entity.setName(employee.getName());
				entity.setDepartment(employee.getDepartment());
				entity.setSalary(employee.getSalary());
				entity.setStatus(employee.isStatus());
				
				return new ResponseEntity<>(dao.save(entity) ,HttpStatus.OK);
			}else {
				return new ResponseEntity<>(HttpStatus.NOT_FOUND);
			}
			
		} catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	  }
	
	  @DeleteMapping("/employee/{id}")
	  @PreAuthorize("hasRole('SUPERADMIN')")
	  public ResponseEntity<Employee> deleteEmployee(@PathVariable("id") Long id) {
		  logger.info("Class :"+getClass().getName()+ " Method: " +new Object(){}.getClass().getEnclosingMethod().getName());
		  try {
			  Optional<Employee> employeeData = dao.findById(id);
				
				if(employeeData.isPresent()) {
					dao.delete(employeeData.get());
					return new ResponseEntity<>(HttpStatus.NO_CONTENT);
				}else {
					return new ResponseEntity<>(HttpStatus.NOT_FOUND);
				}
		} catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	  }
}
